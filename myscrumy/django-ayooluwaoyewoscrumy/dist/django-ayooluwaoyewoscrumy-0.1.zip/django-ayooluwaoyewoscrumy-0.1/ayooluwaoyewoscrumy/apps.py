from django.apps import AppConfig


class AyooluwaoyewoscrumyConfig(AppConfig):
    name = 'ayooluwaoyewoscrumy'
