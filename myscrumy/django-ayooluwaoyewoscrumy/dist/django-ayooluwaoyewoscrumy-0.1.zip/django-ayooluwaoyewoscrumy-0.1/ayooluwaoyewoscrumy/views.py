from ayooluwaoyewoscrumy.models import GoalStatus, ScrumyGoals, ScrumyHistory
from django.contrib.auth.models import User
from .models import SignUpForm, CreateGoalForm
from django.template import loader
from random import *
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import render
from django.urls import reverse
from django.http import HttpResponse, HttpResponseRedirect

# Create your views here.
from .models import ScrumyGoals, GoalStatus


def index(request):
    # return HttpResponse("Hello, world.")
    form = SignUpForm()
    if request.method == 'GET':
        return render(request, 'ayooluwaoyewoscrumy/index.html', {'form':form})
    elif request.method == 'POST':
        form = SignUpForm(request.POST)
        form.save()
    else:
        form = SignUpForm()
    return HttpResponseRedirect(reverse('ayooluwaoyewoscrumyindex:index'))
    # form.save(commit = false)


def scrumygoals(request):
    response = ScrumyGoals.objects.all()
    return HttpResponse(response)

def specificgoal(request):
    response = ScrumyGoals.objects.filter(goal_name ='Learn Django')
    return HttpResponse(response)

def move_goals(request, goal_id):
    try:
        goal = ScrumyGoals.objects.get(pk=goal_id)
    except ObjectDoesNotExist:
        notexist = 'A record with that goal id does not exist'
        context = { 'not_exist': notexist }
        return render(request, 'ayooluwaoyewoscrumy/exception.html', context)
    return HttpResponse(goal)

def add_goal(request):
    form = CreateGoalForm()
    if request.method == 'GET':
        return render(request, 'ayooluwaoyewoscrumy/addgoal.html', {'form':form})
    elif request.method == 'POST':
        form = CreateGoalForm(request.POST)
        post = form.save(commit = False)
        goal_id = randint(1000, 9999)
        status_name = GoalStatus(id = 1)
        post.created_by = "Louis"
        post.moved_by = "Louis"
        post.owner= "Louis"
        post.goal_id = goal_id
        post.goal_status = status_name
        post.save()
    else:
        form = CreateGoalForm()
    return HttpResponseRedirect(reverse('ayooluwaoyewoscrumy:addgoal'))

    # user = User(id = 5)
    # status_name = GoalStatus(id = 1)
    # goal_id = randint(1000, 9999)
    # addgoal = ScrumyGoals.objects.create(goal_name = "Keep Learning Django", goal_id = goal_id, created_by ="Louis", 
    # moved_by = "Louis", owner = "Louis", goal_status = status_name, user = user)
    # return HttpResponse(addgoal)


def home(request):
    scrumygoal = ScrumyGoals.objects.filter(goal_name ='Keep Learning Django')
    # goal = eachgoal.goal_name
    output = ', '.join([eachgoal.goal_name for eachgoal in scrumygoal])
    return HttpResponse(output)

def homepage(request):
    # goalid = ScrumyGoals.objects.get(goal_id=1095)
    # goalname = ScrumyGoals.objects.get(goal_name = 'Keep Learning Django')
    # user = User(id = 5)
    user = User.objects.all()
    weeklygoal = GoalStatus.objects.get(status_name = "Weekly Goal")
    wg = weeklygoal.scrumygoals_set.all()
    dailygoal = GoalStatus.objects.get(status_name = "Daily Goal")
    dg = dailygoal.scrumygoals_set.all()
    verifygoal = GoalStatus.objects.get(status_name = "Verify Goal")
    vg = verifygoal.scrumygoals_set.all()
    donegoal = GoalStatus.objects.get(status_name = "Done Goal")
    gd = donegoal.scrumygoals_set.all()
    context = { 'user':user, 'weeklygoal':wg, 'dailygoal':dg, 'verifygoal':vg, 'donegoal':gd}
    return render(request, 'ayooluwaoyewoscrumy/home.html', context)




